import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:go_router/go_router.dart';
import 'package:hashtagg/core/models/shop.dart';
import 'package:hashtagg/core/network/home_api_repository.dart';
import 'package:hashtagg/core/network/shop_api_repository.dart';
import 'package:hashtagg/features/shop/bloc/public/shop_public_bloc.dart';
import 'package:hashtagg/features/shop/bloc/public/shop_public_event.dart';
import 'package:hashtagg/features/shop/bloc/public/shop_public_state.dart';
import 'package:hashtagg/features/listing/screens/listing_screen.dart' show AnimatedImageSlider;

class ShopPublicScreen extends StatelessWidget {
  final String shopId;

  const ShopPublicScreen({super.key, required this.shopId});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => ShopPublicBloc(
        context.read<ShopApiRepository>(),
      )..add(LoadPublicShop(shopId: shopId)),
      child: const ShopPublicView(),
    );
  }
}

class ShopPublicView extends StatefulWidget {
  const ShopPublicView({super.key});

  @override
  State<ShopPublicView> createState() => _ShopPublicViewState();
}

class _ShopPublicViewState extends State<ShopPublicView>
    with TickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final primaryPurple = const Color(0xFF8B5CF6);

    return BlocBuilder<ShopPublicBloc, ShopPublicState>(
      builder: (context, state) {
        if (state is ShopPublicLoading) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        if (state is ShopPublicError) {
          return Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.error_outline, size: 64, color: Colors.red),
                  const SizedBox(height: 16),
                  Text(
                    "Ошибка: ${state.message}",
                    style: GoogleFonts.montserrat(fontSize: 16),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const ShopPublicView(),
                        ),
                      );
                    },
                    child: const Text('Повторить'),
                  ),
                ],
              ),
            ),
          );
        }

        if (state is ShopPublicLoaded) {
          final shop = state.shop;
          return Scaffold(
            body: NestedScrollView(
              headerSliverBuilder: (context, innerBoxIsScrolled) => [
                _buildAppBar(shop, isDark, primaryPurple),
                SliverToBoxAdapter(child: _buildStats(shop, isDark, state.ads.length)),
                SliverPersistentHeader(
                  pinned: true,
                  delegate: _SliverTabBarDelegate(
                    TabBar(
                      controller: _tabController,
                      labelColor: primaryPurple,
                      unselectedLabelColor: Colors.grey,
                      indicatorColor: primaryPurple,
                      tabs: const [
                        Tab(text: "Товаров"),
                        Tab(text: "Ссылки"),
                      ],
                    ),
                  ),
                ),
              ],
              body: TabBarView(
                controller: _tabController,
                children: [
                  _buildProductsTab(state),
                  _buildLinksTab(),
                ],
              ),
            ),
          );
        }

        return const Scaffold(
          body: Center(child: CircularProgressIndicator()),
        );
      },
    );
  }

  SliverAppBar _buildAppBar(Shop shop, bool isDark, Color primary) {
    return SliverAppBar(
      expandedHeight: 240,
      pinned: true,
      flexibleSpace: FlexibleSpaceBar(
        background: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [primary.withOpacity(0.85), primary.withOpacity(0.6)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircleAvatar(
                  radius: 55,
                  backgroundColor: Colors.white,
                  child: ClipOval(
                    child: CachedNetworkImage(
                      imageUrl: shop.logo ?? '',
                      width: 100,
                      height: 100,
                      fit: BoxFit.cover,
                      placeholder: (_, __) => const Icon(Icons.store, size: 50),
                      errorWidget: (_, __, ___) => const Icon(Icons.store, size: 50),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  shop.title ?? '@unknown',
                  style: GoogleFonts.montserrat(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                if (shop.description != null && shop.description!.isNotEmpty)
                  Text(
                    shop.description!,
                    style: GoogleFonts.montserrat(
                      fontSize: 14,
                      color: Colors.white70,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.share, color: Colors.white),
          onPressed: () {},
        ),
        IconButton(
          icon: const Icon(Icons.more_vert, color: Colors.white),
          onPressed: () {},
        ),
      ],
    );
  }

  Widget _buildStats(Shop shop, bool isDark, int actualAdsCount) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _StatItem(number: "0", label: "Отзывов"),
          _StatItem(
            number: actualAdsCount.toString(), // 👈 Используем реальное число
            label: "Товаров",
          ),
          _StatItem(
            number: shop.subscribersCount.toString(),
            label: "Подписчиков",
          ),
        ],
      ),
    );
  }

  Widget _buildLinks(Shop shop, bool isDark) {
    final links = shop.links ?? [];

    if (links.isEmpty) {
      return const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        children: links.map((link) {
          return Column(
            children: [
              _LinkTile(
                icon: Icons.link,
                title: link.text ?? 'Ссылка',
                color: Colors.blue,
                onTap: () {
                  print('🔗 [ShopPublic] Open link: ${link.link}');
                },
              ),
              if (link != links.last) const Divider(height: 1),
            ],
          );
        }).toList(),
      ),
    );
  }

  Widget _buildProductsTab(ShopPublicLoaded state) {
    final ads = state.ads;

    if (ads.isEmpty) {
      return const Center(
        child: Text(
          'Товаров пока нет',
          style: TextStyle(fontSize: 16, color: Colors.grey),
        ),
      );
    }

    return CustomScrollView(
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.all(12),
          sliver: SliverGrid(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 0.55,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
            ),
            delegate: SliverChildBuilderDelegate(
                  (context, index) {
                final ad = ads[index];
                return _ProductCard(ad: ad);
              },
              childCount: ads.length,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLinksTab() {
    return const Center(
      child: Text(
        "Раздел внешних ссылок и полезных материалов",
        style: TextStyle(fontSize: 16, color: Colors.grey),
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final String number;
  final String label;

  const _StatItem({required this.number, required this.label});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          number,
          style: GoogleFonts.montserrat(
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: GoogleFonts.montserrat(
            fontSize: 13,
            color: Colors.grey,
          ),
        ),
      ],
    );
  }
}

class _LinkTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final Color color;
  final VoidCallback? onTap;

  const _LinkTile({
    required this.icon,
    required this.title,
    required this.color,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: color, size: 28),
      title: Text(
        title,
        style: GoogleFonts.montserrat(fontWeight: FontWeight.w500),
      ),
      trailing: const Icon(Icons.arrow_forward_ios, size: 18),
      onTap: onTap,
    );
  }
}

class _ProductCard extends StatefulWidget {
  final FeedAd ad;

  const _ProductCard({super.key, required this.ad});

  @override
  State<_ProductCard> createState() => _ProductCardState();
}

class _ProductCardState extends State<_ProductCard> {
  late PageController _pageController;
  int _currentPage = 0;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _pageController.addListener(() {
      final page = _pageController.page?.round() ?? 0;
      if (page != _currentPage) {
        setState(() {
          _currentPage = page;
        });
      }
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  // 👇 Функция для "умного" получения URL
  String _getImageUrl(String imgName) {
    if (imgName.startsWith('http')) return imgName;
    return 'https://hashtagg.ru/public/media/images_boards/small/$imgName';
  }

  @override
  Widget build(BuildContext context) {
    final imageUrls = widget.ad.images.map((img) => _getImageUrl(img)).toList();

    return GestureDetector(
      onTap: () {
        context.push('/listing/${widget.ad.id}');
      },
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8)],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 170,
              width: double.infinity,
              child: Stack(
                children: [
                  PageView.builder(
                    controller: _pageController,
                    itemCount: imageUrls.length,
                    itemBuilder: (context, index) {
                      final baseName = widget.ad.images[index];

                      return CachedNetworkImage(
                        // 👇 Сначала пробуем .webp
                        imageUrl: baseName.startsWith('http')
                            ? '${baseName}.webp'
                            : 'https://hashtagg.ru/public/media/images_boards/small/$baseName.webp',

                        fit: BoxFit.cover,
                        placeholder: (context, url) => Container(
                          color: Colors.grey[300],
                          child: const Center(child: CircularProgressIndicator(strokeWidth: 2)),
                        ),

                        // 👇 Если .webp не нашелся, пробуем .jpg
                        errorWidget: (context, url, error) {
                          final jpgUrl = baseName.startsWith('http')
                              ? baseName
                              : 'https://hashtagg.ru/public/media/images_boards/small/$baseName';

                          return CachedNetworkImage(
                            imageUrl: jpgUrl,
                            fit: BoxFit.cover,
                            errorWidget: (context, url, error) => Container(
                              color: Colors.grey[300],
                              child: const Icon(Icons.broken_image),
                            ),
                          );
                        },
                      );
                    },
                  ),

                  if (imageUrls.length > 1)
                    Positioned(
                      top: 8,
                      right: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.6),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.camera_alt, size: 14, color: Colors.white),
                            const SizedBox(width: 4),
                            Text(
                              '${imageUrls.length}',
                              style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      ),
                    ),

                  if (imageUrls.length > 1)
                    Positioned(
                      bottom: 8,
                      left: 0,
                      right: 0,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(imageUrls.length, (index) {
                          final isActive = index == _currentPage;
                          return AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            margin: const EdgeInsets.symmetric(horizontal: 2),
                            width: isActive ? 8 : 6,
                            height: isActive ? 8 : 6,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: isActive ? Colors.white : Colors.white.withOpacity(0.5),
                            ),
                          );
                        }),
                      ),
                    ),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.ad.price.isNotEmpty ? widget.ad.price : 'Цена не указана',
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 6),
                  Text(widget.ad.title, maxLines: 2, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 8),
                  Text(
                    widget.ad.cityName.isNotEmpty ? '${widget.ad.cityName} • ${widget.ad.dateTimeAdd}' : widget.ad.dateTimeAdd,
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Вспомогательный виджет для плавной анимации точки
class AnimatedContainer extends StatelessWidget {
  final Duration duration;
  final double width;
  final double height;
  final EdgeInsetsGeometry margin;
  final Decoration decoration;

  const AnimatedContainer({
    super.key,
    required this.duration,
    required this.width,
    required this.height,
    required this.margin,
    required this.decoration,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      margin: margin,
      decoration: decoration,
    );
  }
}

class _SliverTabBarDelegate extends SliverPersistentHeaderDelegate {
  final TabBar tabBar;

  _SliverTabBarDelegate(this.tabBar);

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: Theme.of(context).scaffoldBackgroundColor,
      child: tabBar,
    );
  }

  @override
  double get maxExtent => tabBar.preferredSize.height;

  @override
  double get minExtent => tabBar.preferredSize.height;

  @override
  bool shouldRebuild(covariant SliverPersistentHeaderDelegate oldDelegate) {
    return false;
  }
}