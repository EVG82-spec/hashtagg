import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hashtagg/core/network/shop_api_repository.dart';
import 'shop_public_event.dart';
import 'shop_public_state.dart';

class ShopPublicBloc extends Bloc<ShopPublicEvent, ShopPublicState> {
  final ShopApiRepository _repository;

  ShopPublicBloc(this._repository) : super(ShopPublicInitial()) {
    on<LoadPublicShop>(_onLoadPublicShop);
  }

  Future<void> _onLoadPublicShop(
      LoadPublicShop event,
      Emitter<ShopPublicState> emit,
      ) async {
    try {
      emit(ShopPublicLoading());

      // Проверяем, что shopId не пустой
      if (event.shopId.isEmpty || event.shopId == '0') {
        print('❌ [ShopPublicBloc] Invalid shopId: ${event.shopId}');
        emit(ShopPublicError('Неверный ID магазина'));
        return;
      }

      final shop = await _repository.getPublicShop(shopId: event.shopId);
      print('🖼️ [ShopPublicBloc] Shop logo: ${shop.logo}');
      print('🖼️ [ShopPublicBloc] Full shop: ${shop.toJson()}');

      // Загружаем товары
      final ads = await _repository.getShopAds(shopId: event.shopId);
      print('🛒 [ShopPublicBloc] Loaded ${ads.length} ads for shop: ${shop.title}');

      emit(ShopPublicLoaded(shop, ads: ads));
    } catch (e) {
      print('❌ [ShopPublicBloc] Error: $e');
      emit(ShopPublicError(e.toString()));
    }
  }
}