import 'package:flutter/foundation.dart';

class Shop {
  final int id;
  final int userId;
  final String idHash;
  final String title;
  final String? description;
  final String? logo;
  final int themeCategoryId;
  final String? themeCategoryName;
  final int status; // 0-модерация, 1-активен, 2-отклонен
  final String? statusNote;
  final DateTime? validityDate;
  final int viewsCount;
  final bool isOwner;
  final bool isActive;
  final List<ShopSlider>? sliders;
  final List<ShopPage>? pages;
  final List<ShopLink>? links;
  final int adsCount;
  final int subscribersCount;

  Shop({
    required this.id,
    required this.userId,
    required this.idHash,
    required this.title,
    this.description,
    this.logo,
    required this.themeCategoryId,
    this.themeCategoryName,
    required this.status,
    this.statusNote,
    this.validityDate,
    required this.viewsCount,
    required this.isOwner,
    required this.isActive,
    this.sliders,
    this.pages,
    this.links,
    required this.adsCount,
    required this.subscribersCount,
  });

  factory Shop.fromJson(Map<String, dynamic> json) {
    // 🔧 ОПРЕДЕЛЯЕМ ФОРМАТ JSON (с префиксом clients_shops_ или без)
    final hasPrefix = json.containsKey('clients_shops_id');

    // Маппинг основных полей
    final id = hasPrefix
        ? _parseInt(json['clients_shops_id'])
        : _parseInt(json['id']);

    final userId = hasPrefix
        ? _parseInt(json['clients_shops_id_user'])
        : _parseInt(json['id_user']);

    final idHash = hasPrefix
        ? (json['clients_shops_id_hash'] as String? ?? '')
        : (json['id_hash'] as String? ?? '');

    final title = hasPrefix
        ? (json['clients_shops_title'] as String? ?? '')
        : (json['title'] as String? ?? '');

    final description = hasPrefix
        ? (json['clients_shops_desc'] as String?)
        : (json['desc'] as String? ?? json['text'] as String?);

    final logoRaw = hasPrefix
        ? (json['clients_shops_logo'] as String?)
        : (json['logo'] as String?);

    final themeCategoryId = hasPrefix
        ? _parseInt(json['clients_shops_id_theme_category'])
        : _parseInt(json['id_theme_category']);

    final status = hasPrefix
        ? _parseInt(json['clients_shops_status'])
        : _parseInt(json['status']);

    final statusNote = hasPrefix
        ? (json['clients_shops_status_note'] as String?)
        : (json['status_note'] as String?);

    final viewsCount = hasPrefix
        ? _parseInt(json['clients_shops_count_view'])
        : (json['count_view'] as int? ?? 0);

    // 🔧 ФОРМИРУЕМ ПОЛНЫЙ URL ДЛЯ ЛОГО
    String? logoUrl = logoRaw;
    if (logoUrl != null && logoUrl.isNotEmpty) {
      if (!logoUrl.startsWith('http')) {
        logoUrl = 'https://hashtagg.ru/media/others/$logoUrl';
      }
    }

    // 🔧 ПАРСИМ КОЛИЧЕСТВО ТОВАРОВ (с логами)
    int adsCount = 0;

    print('🔍 [Shop Model] Parsing adsCount for shop: ${json['clients_shops_title'] ?? json['title']}');
    print('🔍 [Shop Model] Raw JSON keys related to ads: ${json.keys.where((k) => k.contains('count') || k.contains('ads')).toList()}');

    // 1. Проверяем стандартное поле (из детального просмотра)
    if (json['count_ads'] != null) {
      print('✅ [Shop Model] Found count_ads: ${json['count_ads']}');
      adsCount = _parseAdsCount(json['count_ads']);
    }
    // 2. Проверяем поле с префиксом (из списка магазинов)
    else if (json['clients_shops_count_ads'] != null) {
      print('✅ [Shop Model] Found clients_shops_count_ads: ${json['clients_shops_count_ads']}');
      adsCount = _parseInt(json['clients_shops_count_ads']);
    }
    // 3. Проверяем альтернативные названия
    else if (json['ads_count'] != null) {
      print('✅ [Shop Model] Found ads_count: ${json['ads_count']}');
      adsCount = _parseInt(json['ads_count']);
    } else {
      print('⚠️ [Shop Model] No ads count field found in JSON!');
    }

    print('🏁 [Shop Model] Final adsCount value: $adsCount');

    return Shop(
      id: id,
      userId: userId,
      idHash: idHash,
      title: title,
      description: description,
      logo: logoUrl,
      themeCategoryId: themeCategoryId,
      themeCategoryName: json['name_theme_category'] as String?,
      status: status,
      statusNote: statusNote,
      validityDate: null,
      viewsCount: viewsCount,
      isOwner: json['owner'] == true || json['owner'] == 1,
      isActive: json['activity_shop'] == true || json['activity_shop'] == 1,
      sliders: json['sliders'] != null
          ? (json['sliders'] as List)
          .map((s) {
        if (s is String) {
          return ShopSlider(name: '', link: s);
        } else if (s is Map) {
          return ShopSlider.fromJson(s as Map<String, dynamic>);
        }
        return ShopSlider(name: '', link: '');
      })
          .toList()
          : null,
      pages: json['pages'] != null
          ? (json['pages'] as List)
          .map((p) => ShopPage.fromJson(p))
          .toList()
          : null,
      links: _parseLinks(json),
      adsCount: adsCount,
      subscribersCount: _parseInt(json['subscribers_count']),
    );
  }

  static List<ShopLink>? _parseLinks(Map<String, dynamic> json) {
    final links = <ShopLink>[];

    for (int i = 1; i <= 3; i++) {
      final text = json['link_${i}_text'] as String?;
      final link = json['link_${i}_link'] as String?;
      final image = json['link_${i}_image'] as String?;

      if ((text != null && text.isNotEmpty) ||
          (link != null && link.isNotEmpty) ||
          (image != null && image.isNotEmpty)) {
        links.add(ShopLink(
          text: text,
          link: link,
          image: image,
        ));
      }
    }

    return links.isEmpty ? null : links;
  }

  static int _parseAdsCount(dynamic value) {
    if (value == null) return 0;
    if (value is int) return value;
    if (value is String) {
      // Ищем первое число в строке (например, "1" из "1 объявление")
      final match = RegExp(r'\d+').firstMatch(value);
      if (match != null) {
        return int.tryParse(match.group(0)!) ?? 0;
      }
      return int.tryParse(value) ?? 0;
    }
    return 0;
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'id_user': userId,
      'id_hash': idHash,
      'title': title,
      'text': description,
      'logo': logo,
      'id_theme_category': themeCategoryId,
      'name_theme_category': themeCategoryName,
      'status': status,
      'status_note': statusNote,
      'owner': isOwner,
      'activity_shop': isActive,
      'sliders': sliders?.map((s) => s.toJson()).toList(),
      'pages': pages?.map((p) => p.toJson()).toList(),
      'links': links?.map((l) => l.toJson()).toList(),
      'subscribers_count': subscribersCount,
    };
  }

  static int _parseInt(dynamic value) {
    if (value == null) return 0;
    if (value is int) return value;
    if (value is String) return int.tryParse(value) ?? 0;
    return 0;
  }

  Shop copyWith({
    int? id,
    int? userId,
    String? idHash,
    String? title,
    String? description,
    String? logo,
    int? themeCategoryId,
    String? themeCategoryName,
    int? status,
    String? statusNote,
    DateTime? validityDate,
    int? viewsCount,
    bool? isOwner,
    bool? isActive,
    List<ShopSlider>? sliders,
    List<ShopPage>? pages,
    List<ShopLink>? links,
    int? adsCount,
    int? subscribersCount,
  }) {
    return Shop(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      idHash: idHash ?? this.idHash,
      title: title ?? this.title,
      description: description ?? this.description,
      logo: logo ?? this.logo,
      themeCategoryId: themeCategoryId ?? this.themeCategoryId,
      themeCategoryName: themeCategoryName ?? this.themeCategoryName,
      status: status ?? this.status,
      statusNote: statusNote ?? this.statusNote,
      validityDate: validityDate ?? this.validityDate,
      viewsCount: viewsCount ?? this.viewsCount,
      isOwner: isOwner ?? this.isOwner,
      isActive: isActive ?? this.isActive,
      sliders: sliders ?? this.sliders,
      pages: pages ?? this.pages,
      links: links ?? this.links,
      adsCount: adsCount ?? this.adsCount,
      subscribersCount: subscribersCount ?? this.subscribersCount,
    );
  }
}

class ShopSlider {
  final int? id;
  final String name;
  final String link;

  ShopSlider({
    this.id,
    required this.name,
    required this.link,
  });

  factory ShopSlider.fromJson(Map<String, dynamic> json) {
    return ShopSlider(
      id: _parseIntNullable(json['id']),
      name: json['name'] as String? ?? '',
      link: json['link'] as String? ?? '',
    );
  }

  static int? _parseIntNullable(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    if (value is String) return int.tryParse(value);
    return null;
  }

  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'name': name,
      'link': link,
    };
  }
}

class ShopPage {
  final int id;
  final String name;
  final String text;
  final String? alias;
  final int status;

  ShopPage({
    required this.id,
    required this.name,
    required this.text,
    this.alias,
    this.status = 1,
  });

  factory ShopPage.fromJson(Map<String, dynamic> json) {
    return ShopPage(
      id: _parseInt(json['id']),
      name: json['name'] as String? ?? '',
      text: json['text'] as String? ?? '',
      alias: json['alias'] as String?,
      status: _parseInt(json['status']),
    );
  }

  static int _parseInt(dynamic value) {
    if (value == null) return 0;
    if (value is int) return value;
    if (value is String) return int.tryParse(value) ?? 0;
    return 0;
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'text': text,
      if (alias != null) 'alias': alias,
      'status': status,
    };
  }
}

class ShopCategory {
  final int id;
  final String name;

  ShopCategory({
    required this.id,
    required this.name,
  });

  factory ShopCategory.fromJson(Map<String, dynamic> json) {
    return ShopCategory(
      id: _parseInt(json['id']),
      name: json['name'] as String? ?? '',
    );
  }

  static int _parseInt(dynamic value) {
    if (value == null) return 0;
    if (value is int) return value;
    if (value is String) return int.tryParse(value) ?? 0;
    return 0;
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
    };
  }
}

class ShopLink {
  final String? image;
  final String? text;
  final String? link;

  ShopLink({
    this.image,
    this.text,
    this.link,
  });

  factory ShopLink.fromJson(Map<String, dynamic> json) {
    return ShopLink(
      image: json['image'] as String?,
      text: json['text'] as String?,
      link: json['link'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      if (image != null) 'image': image,
      if (text != null) 'text': text,
      if (link != null) 'link': link,
    };
  }

  bool get isEmpty => (image == null || image!.isEmpty) && 
                      (text == null || text!.isEmpty) && 
                      (link == null || link!.isEmpty);
}
